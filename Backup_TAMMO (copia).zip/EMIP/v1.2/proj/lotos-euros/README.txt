Settings to produce LOTOS-EUROS input:
- TROPOMI/NO2 data to be simulated

