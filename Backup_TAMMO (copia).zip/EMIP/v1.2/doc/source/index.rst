.. EMIP documentation master file.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. _EMIP:

EMIP
======

EMEP Model Input Processor.


Contents
========

.. The following are names of '.rst' files,
   section titles and toctrees are used to form the table-of-contents.
    
.. toctree::
   :maxdepth: 2

   tutorial
   emip_omi
   emip_tropomi
   python-modules
   documentation



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

