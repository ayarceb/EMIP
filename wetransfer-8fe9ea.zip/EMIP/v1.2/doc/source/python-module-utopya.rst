.. Documentation for module.

.. Import documentation from ".py" file:
.. automodule:: utopya

